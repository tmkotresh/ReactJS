import React ,{useEffect} from 'react';
import { DangerButton } from './Button';

// To Demonstrate State usign Hooks
export const CounterButton = ({onIncrement,numberOfClicks}) => {
    useEffect (()=>{
        console.log('useEffect functional called');
    },[]);
    
    return (
        <>
        <p>You have clicked {numberOfClicks} times</p>
        <DangerButton buttonColor="red" onClick={onIncrement}>Click Me!</DangerButton>
        </>
    );
}