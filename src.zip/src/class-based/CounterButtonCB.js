import React from 'react';

export class CounterButtonCB extends React.Component {
    render() {
        const { numberOfClicks, onIncrement} = this.props;
        <>
        <p>You have clicked {numberOfClicks} times</p>
        <button onClick={onIncrement}>Click Me!</button>
        </>
    }
}