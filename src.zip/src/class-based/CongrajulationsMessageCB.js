import React from 'react';

export class CongrajulationsMessageCB extends React.Component {
    render(){
        const {threshold, onHide } = this.props;
        return (
            <>
            <h3>Congrajulations!! You have reached threshold by clicking {threshold} number of times. </h3>
            <button onClick={onHide}>Hide</button>
            </>
        );
    }
}