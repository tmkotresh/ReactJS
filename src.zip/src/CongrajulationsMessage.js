import React ,{useEffect} from 'react';
import { Button } from './Button';

export const CongrajulationsMessages = ({threshold,onHide}) =>{
    return (
            <>
            <h3>Congrajulations!! You have reached threshold by clicking {threshold} number of times. </h3>
            <Button onClick={onHide}>Hide</Button>
            </>
        );
  
}