import React ,{useState} from 'react';
import { SuccessButton } from '../Button';

export const ControlledFormPage = () => {
    const[name,setName] = useState('');
    const[email,setEmail] = useState('');
    const[favoriteColor,setFavouriteColor] = useState('');
    return (
        <form>
          <h3> Please enter your information</h3>
          <div>
              <input 
              type="text" 
              placeholder="Name" 
              value= {name}
              onChange = { e=>setName(e.target.value)} />
          </div>
          <div>
              <input type="text" 
              placeholder="Email"
              value = {email}
              onChange = {e => setEmail(e.target.value)} 
              />
          </div>
          <div>
              <input type="text" 
              placeholder="FavoriteColor"
              value = {favoriteColor}
              onChange= {e=> setFavouriteColor(e.target.value)} />
          </div>
          <SuccessButton buttonColor='green' onClick={e =>{
              alert(`
                Your Name is ${name},
                Your Email is ${email},
                and Your Favorite color is ${favoriteColor}
              `)
              e.preventDefault();
          }}>Submit</SuccessButton>
        </form>
        

    );
}