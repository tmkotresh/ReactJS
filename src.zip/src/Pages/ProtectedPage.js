import Rect, { useEffect } from 'react';
import { Redirect, useHistory } from 'react-router';


export const ProtectedPage = () => {
    const history = useHistory();
    const isAuthed = false;
    useEffect(() => {
        if (!isAuthed) {
            history.push('/');
        }

    });
   return (
       <h1>Protected page</h1>
   )
    
}