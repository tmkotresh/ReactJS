export {CounterButtonPage} from './CounterButtonPage';
export {PeopleListPage} from './PeopleListPage';
export {HomePage} from './HomePage';
export {NotFoundPage} from './NotFoundPage';
export {ProtectedPage} from './ProtectedPage';
export {ControlledFormPage} from './ControlledFormPage';
export {UnControlledFormPage} from './UnControlledFormPage';
export {UserProfilePage} from './UserProfilePage';