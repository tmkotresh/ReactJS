import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom';
import { HomePage,
         CounterButtonPage,
         PeopleListPage,
         NotFoundPage,
         ProtectedPage,
         ControlledFormPage,
         UnControlledFormPage,
         UserProfilePage } from './Pages';
import { UserDataLoader } from './UserDataLoader';
import { NavBar } from './NavBar';
import { FormsNavBar } from './FormsNavBar';
import { ThemeContext } from './ThemeContext';
import React, { useState } from 'react';
import './App.css';



const displayAlert = () => {
  alert('Hello there!');
}

function App() {

  const [numberOfClicks, setNumberOfClicks] = useState(0);
  const increment = () => setNumberOfClicks(numberOfClicks + 1);
  const [hideMessage, setHideMessage] = useState(false);
  return (
    <ThemeContext.Provider value="dark">
       <div className="App">
      <Router>
        <NavBar />
        <div className="App-header">
        <Switch>
          <Route path="/" exact>
            <HomePage />
          </Route>
          <Route path="/counter">
            <CounterButtonPage />
          </Route>
          <Route path="/people-list">
            <PeopleListPage />
          </Route>
          <Route path="/users">
            <UserProfilePage />
          </Route>
          <Route path="/forms">
            <FormsNavBar />
          <Route path="/forms/controlled">
           <ControlledFormPage />
          </Route>
          <Route path ="/forms/uncontrolled">
            <UnControlledFormPage />
          </Route>
          </Route>
          
          <Route path ='/protected'><ProtectedPage /></Route>
          <Route>
            <NotFoundPage />
          </Route>
        </Switch>
        </div>
       </Router>
    </div>
    </ThemeContext.Provider>
    
  );
}

export default App;
